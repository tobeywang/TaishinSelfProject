﻿/**
 * OpenDrawApp 開源抽獎程式 純 JavaScript 版本 Ver 1.0.1
 * 匯入（import ）核心邏輯
 */

import { luckyDraw, objectsToCSV, downloadTextFile } from './OpenDrawJs.js';

document.addEventListener('DOMContentLoaded', function () {
    // 取得 DOM 元素
    const csvFileInput = document.getElementById('csvFile');
    const topInput = document.getElementById('top');
    const sampleSeedInput = document.getElementById('sampleSeed');
    const drawSeedInput = document.getElementById('drawSeed');
    const extraSeedInput = document.getElementById('extraSeed');
    const displayFieldsInput = document.getElementById('displayFields');
    const removeWinnersCheckbox = document.getElementById('removeWinners');
    const startDrawButton = document.getElementById('startDraw');
    const downloadLogButton = document.getElementById('downloadLog');
    const downloadWinnersButton = document.getElementById('downloadWinners');
    const clearLogButton = document.getElementById('clearLog');
    const logElement = document.getElementById('log');
    const loadingElement = document.getElementById('loading');
    const resultTableElement = document.getElementById('resultTable');

    // 應用程式狀態變數
    let csvContent = '';
    let drawResult = null;

    // 在日誌區域顯示訊息
    function logMessage(message, color = '') {
        const messageElement = document.createElement('div');
        messageElement.textContent = message;
        if (color) messageElement.style.color = color;
        logElement.appendChild(messageElement);
        logElement.scrollTop = logElement.scrollHeight;
    }

    // 清除日誌與結果
    clearLogButton.addEventListener('click', function () {
        logElement.innerHTML = '';
        resultTableElement.innerHTML = '';
        downloadLogButton.classList.add('hidden');
        downloadWinnersButton.classList.add('hidden');
        drawResult = null;
    });

    // 處理 CSV 檔案上傳
    csvFileInput.addEventListener('change', function (e) {
        const file = e.target.files[0];
        if (!file) return;

        const reader = new FileReader();
        reader.onload = function (e) {
            csvContent = e.target.result;
            clearLogButton.click();
            logMessage(`已載入 CSV 檔案: ${file.name}`, 'green');
        };
        reader.readAsText(file);
    });

    // 開始抽獎按鈕事件
    startDrawButton.addEventListener('click', async function () {
        if (!csvContent) {
            alert('請先上傳抽獎名單 CSV 檔案！');
            return;
        }

        clearLogButton.click();
        loadingElement.classList.remove('hidden');
        startDrawButton.disabled = true;

        try {
            const options = {
                csvContent: csvContent,
                top: parseInt(topInput.value) || 10,
                sampleSeed: sampleSeedInput.value || null,
                drawSeed: drawSeedInput.value || null,
                extraSeed: extraSeedInput.value || null,
                displayFields: displayFieldsInput.value ? displayFieldsInput.value.split(',').map(f => f.trim()) : [],
                removeWinners: removeWinnersCheckbox.checked,
                logCallback: logMessage
            };

            drawResult = await luckyDraw(options);

            if (drawResult && !drawResult.error) {
                displayResultTable(drawResult);
                downloadLogButton.classList.remove('hidden');
                downloadWinnersButton.classList.remove('hidden');
            }
        } catch (error) {
            logMessage(`發生未預期的錯誤: ${error.message}`, '#FF0000');
            console.error(error);
        } finally {
            loadingElement.classList.add('hidden');
            startDrawButton.disabled = false;
        }
    });

    // 顯示結果表格
    function displayResultTable(result) {
        if (!result || !result.winners || result.winners.length === 0) return;

        const { winners, displayFields } = result;
        resultTableElement.innerHTML = ''; // 清空舊表格

        // 建立表頭
        const thead = resultTableElement.createTHead();
        const headerRow = thead.insertRow();
        const th_no = document.createElement('th');
        th_no.textContent = '序號';
        headerRow.appendChild(th_no);
        displayFields.forEach(field => {
            const th = document.createElement('th');
            th.textContent = field;
            headerRow.appendChild(th);
        });

        // 建立表格內容
        const tbody = resultTableElement.createTBody();
        winners.forEach((winner, index) => {
            const tr = tbody.insertRow();
            tr.insertCell().textContent = index + 1;
            displayFields.forEach(field => {
                tr.insertCell().textContent = winner[field] || '';
            });
        });
    }

    // 下載日誌按鈕事件
    downloadLogButton.addEventListener('click', function () {
        if (!drawResult || !drawResult.log) return;
        const timestamp = new Date().toISOString().replace(/[:.]/g, '-').substring(0, 15);
        downloadTextFile(drawResult.log, `抽獎日誌_${timestamp}.txt`);
    });

    // 下載中獎名單按鈕事件
    downloadWinnersButton.addEventListener('click', function () {
        if (!drawResult || !drawResult.winners || drawResult.winners.length === 0) return;
        const { headers, winners } = drawResult;
        const winnersCSV = objectsToCSV(headers, winners);
        const timestamp = new Date().toISOString().replace(/[:.]/g, '-').substring(0, 15);
        downloadTextFile(winnersCSV, `中獎名單_${timestamp}.csv`, 'text/csv;charset=utf-8;');
    });
});
