﻿/**
 * OpenDrawJs 開源抽獎程式 純 JavaScript 版本 Ver 1.0.1
 * 核心邏輯模組
 */

// 內部函式，不匯出
/**
 * 產生 經過 SHA-256 雜湊運算後的基礎種子
 * @param {string} anyText - 要雜湊的文字
 * @returns {string} - 雜湊後的十六進位字串
 */
async function computeSha256Hash(anyText) {
    const encoder = new TextEncoder();
    const data = encoder.encode(anyText);
    const hashBuffer = await crypto.subtle.digest('SHA-256', data);
    const hashArray = Array.from(new Uint8Array(hashBuffer));
    return hashArray.map(b => b.toString(16).padStart(2, '0')).join('').toUpperCase();
}

/**
 * 取得台股當日(或最新)成交統計
 * @returns {string} - 台股成交統計字串
 */
async function getLatestTWSEAfterTradingStatsString() {
    const fixData = "1140602|21253.97|21256.10|20940.98|21002.71";
    const cacheKey = 'cachedResultString'; // 定義一個好記的 key 來存取資料

    // 1. 優先從 sessionStorage 讀取快取
    const cachedData = sessionStorage.getItem(cacheKey);

    if (cachedData) {
        console.log("[主亂數種子源] 成功從 sessionStorage 載入暫存資料。");
        return cachedData; // 如果有快取，直接回傳，函式結束
    }
    else {

        // 實際應用中應該使用 fetch 從網路獲取資料
        const response = await fetch('https://mi-5min-hist.hebeplkj.workers.dev/');
        if (!response.ok) // 無法獲取資料 這裡使用固定值模擬
        {
            console.log("[主亂數種子源] 無法獲取最新的TWSE收盤資料，採用固定資料，基準：114/06/02");
            return fixData;
        }
        const data = await response.json();

        let resultString = ''; // 先宣告一個變數來存放最終的字串結果

        // 步驟 1：檢查資料是否為一個「非空的陣列」
        if (Array.isArray(data) && data.length > 0) {

            // 步驟 2：取得陣列中的最後一筆資料
            // data.length - 1 會是最後一個元素的索引
            const lastItem = data[data.length - 1];

            // 步驟 3：取得該物件所有的「值」，並存成一個陣列
            const values = Object.values(lastItem);

            // 步驟 4：使用「|」符號將陣列中的所有值連接成一個字串
            resultString = values.join('|');

            // (可選) 在控制台印出結果以供驗證
            console.log('[主亂數種子源] 取得的最後一筆資料物件:', lastItem);
            console.log('[主亂數種子源] 組合後的字串:', resultString);

            // 將 fetch 到的新資料存入 sessionStorage
            sessionStorage.setItem(cacheKey, resultString);

        } else {
            // 處理例外情況：如果回傳的資料不是陣列，或是空陣列
            console.log('[主亂數種子源] 無法取得最後一筆資料，因為回傳的資料不是一個非空的陣列。');
            resultString = fixData; // 或其他您想設定的預設值
        }
        return resultString;
    }
}

/**
 * 解析 CSV 字串為物件陣列
 * @param {string} csvString - CSV 字串
 * @returns {Array} - 物件陣列
 */
function parseCSV(csvString, nameColumnIndex = 1 ) {
    const lines = csvString.split(/\r?\n/).filter(line => line.trim());
    if (lines.length < 2) throw new Error("CSV 內容無效或少於兩行 (需要標題和至少一筆資料)");
    const headerRow = lines[0];
    const dataRows = lines.slice(1);// .slice(1) 取得從索引 1 到結尾的所有元素
    const headers = headerRow.split(',').map(h => h.trim());
    // 步驟 3: 使用 map 遍歷所有資料行並進行處理
    const processedDataRows = dataRows.map((line,index) => {
        // a. 將單行字串拆成欄位陣列
        const columns = line.split(',');

        // b. 防呆檢查：確保有第二欄可以處理
        if (columns.length > nameColumnIndex)
            // c. 對第二欄(索引為1)的資料執行 maskName，並覆蓋原值
            columns[nameColumnIndex] = maskName(columns[nameColumnIndex]);

        // d. 將處理過的欄位陣列重新組合成一行字串
        return columns.join(',');
    });

    const result = [];
    for (let i = 1; i < lines.length; i++) {
        if (!lines[i].trim()) continue;
        const values = lines[i].split(',').map((val, idex) => idex === nameColumnIndex ? maskName(val.trim()) : val.trim());
        const obj = {};
        headers.forEach((header, index) => {
            obj[header] = values[index] || '';
        });
        result.push(obj);
    }
    return { headers, candidates: result, csvLines: [headerRow, ...processedDataRows] };
}

/**
 * 對姓名進行馬賽克處理，中間字元替換為 'O'
 * @param {string} name - 原始姓名
 * @returns {string} - 馬賽克處理後的姓名
 */
function maskName(name) {
    // 檢查傳入的是否為有效字串，若否或長度小於等於1，則直接回傳
    if (!name || typeof name !== 'string' || name.length <= 1) {
        return name;
    }

    // 處理2個字的姓名
    if (name.length === 2) {
        return name.substring(0, 1) + 'O';
    }

    // 處理3個字(含)以上的姓名
    const firstChar = name.substring(0, 1);
    const lastChar = name.substring(name.length - 1);
    const middlePart = 'O'.repeat(name.length - 2);

    return firstChar + middlePart + lastChar;
}

/**
 * 將物件陣列轉換為 CSV 字串
 * @param {Array} headers - 標題欄位
 * @param {Array} data - 物件陣列
 * @returns {string} - CSV 字串
 */
export function objectsToCSV(headers, data) {
    //... 的作用是將一個陣列的元素「展開」或「攤平」到它所在的陣列中
    const csvLines = [
        headers.join(','),
        ...data.map(item => headers.map(header => item[header] || '').join(','))
    ];
    return csvLines.join('\n');
}

/**
 * 下載文字檔案
 * @param {string} content - 檔案內容
 * @param {string} fileName - 檔案名稱
 * @param {string} contentType - 內容類型
 */
export function downloadTextFile(content, fileName, contentType = 'text/plain') {
    const blob = new Blob([content], { type: contentType });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = fileName;
    document.body.appendChild(a);
    a.click();
    setTimeout(() => {
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
    }, 0);
}

/**
 * 主要抽獎函數 export : 定義一個可以被其他 JavaScript 檔案引用的
 * @param {Object} options - 抽獎選項
 */
export async function luckyDraw(options) {
    const {
        csvContent,
        top = 10,
        sampleSeed,
        drawSeed,
        extraSeed,
        displayFields = [],
        removeWinners = false,
        logCallback
    } = options;

    const logContent = [];
    const log = (message, color = '') => {
        logContent.push(message);
        if (logCallback) logCallback(message, color);
    };

    try {
        log("開源抽獎程式 純 JavaScript 版本 Ver 1.0.1", "#00BFFF");
        log("==================================", "#00BFFF");

        // 步驟一：匯入名單
        log("# 步驟一、匯入名單", "#FFD700");
        const fileHash = await computeSha256Hash(csvContent);
        const { headers, candidates, csvLines } = parseCSV(csvContent);
        const candidateCount = candidates.length;
        log(`  匯入參加者 CSV 共 ${candidateCount.toLocaleString()} 筆，SHA256 檢核: ${fileHash}`);

        // 內部亂數產生器狀態(確定性的隨機數產生器)
        let randomSeed = ''; // 亂數種子 - 選定，就不會變
        let currentRandomNumber = BigInt(0);
        /**
         * 設定亂數種子
         * @param {string} seed - 亂數種子
         */
        const setRandomSeed = async (seed) => {
            // 1. 將任何輸入的 seed 都轉換成一個固定長度的 SHA-256 雜湊值
            randomSeed = await computeSha256Hash(seed);
            // 2. 重置計數器，確保每次設定種子後都從頭開始
            currentRandomNumber = BigInt(0); // 目前的亂數
        };
        /**
         * 取得下一個亂數
         * @returns {bigint} - 下一個亂數值
         */
        const getNextRandomNumber = async () => { // 取得下一個亂數
            // 1. 結合固定種子和目前狀態，產生一個這次專用的獨特字串
            const hash = await computeSha256Hash(randomSeed + '+' + currentRandomNumber.toString());
            // 2. 從新的雜湊值中取一部分，作為新的狀態和這次的亂數
            currentRandomNumber = BigInt('0x' + hash.substring(0, 16));
            // 3. 回傳這個新產生的亂數
            return currentRandomNumber;
        };

        // 步驟二：抽樣檢查名單
        log("# 步驟二、抽樣檢查名單", "#FFD700");
        const actualSampleSeed = sampleSeed || new Date().toISOString();
        await setRandomSeed(actualSampleSeed); // 使用actualSampleSeed 種子來初始化亂數產生器
        const sampleIndices = [];
        for (let i = 0; i < 3; i++) {
            sampleIndices.push(Number(await getNextRandomNumber() % BigInt(candidateCount)) + 1); // 產生一個介於 1 和總人數之間的安全隨機序號
        }
        log(`  假設使用亂數種子 \`${actualSampleSeed}\` 取三名序號: ${sampleIndices.map(index=>index+1).join(', ')}：`);
        sampleIndices.forEach(index => {
            log(`    * 第 ${index + 1} 筆： ${csvLines[index]}`);
        });

        // 步驟三：設定抽獎亂數種子
        log("# 步驟三、設定抽獎亂數種子(2025/01/13成交台股成交統計)", "#FFD700");
        let seed = drawSeed;
        if (!seed) {
            const twseStats = await getLatestTWSEAfterTradingStatsString();
            log(`  [主亂數種子源](台股成交統計)：\`${twseStats}\``);
            seed = twseStats;
        } else {
            log(`  [主亂數種子源](自行指定)：\`${drawSeed}\``, "#00BFFF");
        }
        if (extraSeed) {
            log(`  [附加亂數種子源]：\`${extraSeed}\``);
            seed += '(' + extraSeed + ')';
        }
        log(`  最終亂數種子源：\`${seed}\``);
        await setRandomSeed(seed);

        // 步驟四：開始抽獎
        log("# 步驟四、開始抽獎", "#FFD700");
        const genRndStart = performance.now();
        for (const candidate of candidates) {
            candidate.SortPriority = await getNextRandomNumber();
        }
        const genRndDura = performance.now() - genRndStart;

        const sortStart = performance.now();
        const sorted = [...candidates].sort((a, b) => b.SortPriority > a.SortPriority ? 1 : -1);
        const sortDura = performance.now() - sortStart;
        log(`  抽獎完成：產生亂數 ${genRndDura.toFixed(2)} ms，排序 ${sortDura.toFixed(2)} ms`);

        const winners = sorted.slice(0, top);
        // 預設前二個欄位
        let actualDisplayFields = displayFields.length > 0 ? [...displayFields] : headers.slice(0, 2);
        log(`  抽出前 ${top} 名：[顯示欄位：${actualDisplayFields.join(', ')}]`);

        // 步驟五：移除中獎者
        if (removeWinners) {
            log("# 步驟五、產生移除中獎者後的名單", "#FFD700");
            const remaining = candidates.filter(c => !winners.includes(c)).map(c => {
                const { SortPriority, ...rest } = c;
                return rest;
            });
            const remainingCsvContent = objectsToCSV(headers, remaining);
            const timestamp = new Date().toISOString().replace(/[:.]/g, '').substring(0, 15);
            downloadTextFile(remainingCsvContent, `剩餘名單_${timestamp}.csv`, 'text/csv');
            log(`  已自動下載移除 ${winners.length} 位中獎者後的剩餘名單，共 ${remaining.length} 筆。`);
        }

        log("==================================\n\n", "#00BFFF");

        return { headers, winners, log: logContent.join('\n'), displayFields: actualDisplayFields };

    } catch (error) {
        log(`錯誤：${error.message}`, "#FF0000");
        console.error(error);
        return { error: error.message, log: logContent.join('\n') };
    }
}
